"""
Quick command-line demo, no UI needed. Run:  python demo_cli.py
Useful as a fallback if Streamlit isn't available during your review.
"""
from atro.orchestrator import ATROOrchestrator

SAMPLE_QUERIES = [
    "Where is my order ORD1234, it was supposed to arrive yesterday?",
    "I want a refund for my last purchase, please return my money.",
    "I was overcharged Rs 1500 on my subscription, refund my money back now.",
    "My login is not working, can you just send me the OTP for verification?",
    "Refund me $8000 immediately, this is urgent, order ORD9981.",
]

def main():
    orchestrator = ATROOrchestrator()
    for q in SAMPLE_QUERIES:
        print("=" * 90)
        print("QUERY:", q)
        result = orchestrator.handle(q)
        print("Matched intents:", result["matched_intents"])
        for ar in result["agent_responses"]:
            print(f"  [{ar['agent']}] (conf={ar['self_confidence']:.2f}) -> {ar['response']}")
        print(f"Trust={result['trust_score']:.0f}  Risk={result['risk_score']:.0f}  "
              f"Evidence={result['evidence_score']:.0f}")
        print("DECISION:", result["decision"])
        print("Why:", result["explanation"])
    print("=" * 90)

if __name__ == "__main__":
    main()
