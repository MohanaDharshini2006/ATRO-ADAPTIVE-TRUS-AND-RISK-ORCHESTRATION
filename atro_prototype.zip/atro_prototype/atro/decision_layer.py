"""
Decision Intelligence Layer (the core novelty of ATRO).

Given one or more AgentResponse objects for a query, this module computes:
  - trust_score   : how much to believe the response (0-100)
  - risk_score    : security / fraud risk of the interaction (0-100)
  - evidence_score: how well-grounded the response is (0-100)
  - conflict_flag : whether multiple agents disagree on intent/action
and returns a final decision: ACCEPT / REQUEST_VERIFICATION /
INVOKE_ADDITIONAL_AGENT / ESCALATE_TO_HUMAN, with a plain-English
explanation (for the "explainable" requirement in the problem statement).
"""

import json
import os
import re
from dataclasses import dataclass, asdict

HISTORY_FILE = os.path.join(os.path.dirname(__file__), "agent_history.json")

DEFAULT_HISTORY = {
    "billing_agent": 0.88,
    "refund_agent": 0.80,
    "order_agent": 0.90,
    "tech_support_agent": 0.78,
}

SECURITY_KEYWORDS = [
    "otp", "one time password", "cvv", "card number", "credit card number",
    "ssn", "social security", "bank account number", "wire transfer",
    "gift card", "send money urgently", "share your password",
]

HIGH_VALUE_PATTERN = re.compile(r"(?:rs\.?|inr|\$|usd)\s?(\d{4,})", re.I)


def _load_history() -> dict:
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE) as f:
                data = json.load(f)
            merged = dict(DEFAULT_HISTORY)
            merged.update(data)
            return merged
        except Exception:
            pass
    return dict(DEFAULT_HISTORY)


def _save_history(history: dict):
    try:
        with open(HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
    except Exception:
        pass  # prototype: never let persistence errors break a demo


@dataclass
class DecisionResult:
    decision: str
    trust_score: float
    risk_score: float
    evidence_score: float
    conflict_detected: bool
    security_flags: list
    explanation: str
    per_agent: list


class DecisionIntelligenceLayer:
    def __init__(self):
        self.history = _load_history()

    # ---- individual signal computations -------------------------------

    def _evidence_score(self, agent_response) -> float:
        ev = agent_response.evidence or {}
        score = 20.0  # baseline
        if ev.get("order_id"):
            score += 35
        if ev.get("amount_found") is not None:
            score += 25
        if ev.get("status"):
            score += 20
        return min(score, 100.0)

    def _security_flags(self, query: str) -> list:
        ql = query.lower()
        return [kw for kw in SECURITY_KEYWORDS if kw in ql]

    def _risk_score(self, query: str, security_flags: list) -> float:
        risk = 5.0  # base low risk
        risk += 25 * len(security_flags)
        m = HIGH_VALUE_PATTERN.search(query)
        if m:
            amount = float(m.group(1))
            if amount >= 5000:
                risk += 35  # high-value transaction = higher scrutiny
            elif amount >= 2000:
                risk += 20
        if "urgent" in query.lower() or "immediately" in query.lower():
            risk += 15  # urgency + money is a classic fraud/social-engineering pattern
        return min(risk, 100.0)

    def _trust_score(self, agent_response, evidence_score: float) -> float:
        hist = self.history.get(agent_response.agent_name, 0.75) * 100
        conf = agent_response.self_confidence * 100
        # weighted blend: self-reported confidence, evidence quality, track record
        trust = 0.35 * conf + 0.35 * evidence_score + 0.30 * hist
        return round(min(trust, 100.0), 1)

    # ---- orchestration --------------------------------------------------

    def evaluate(self, query: str, agent_responses: list) -> DecisionResult:
        security_flags = self._security_flags(query)
        risk_score = self._risk_score(query, security_flags)

        per_agent_scores = []
        for ar in agent_responses:
            ev_score = self._evidence_score(ar)
            trust_score = self._trust_score(ar, ev_score)
            per_agent_scores.append({
                "agent": ar.agent_name,
                "response": ar.response_text,
                "self_confidence": ar.self_confidence,
                "evidence_score": ev_score,
                "trust_score": trust_score,
                "historical_accuracy": self.history.get(ar.agent_name, 0.75),
            })

        conflict_detected = len(agent_responses) > 1

        best = max(per_agent_scores, key=lambda x: x["trust_score"])
        trust_score = best["trust_score"]
        evidence_score = best["evidence_score"]

        decision, explanation = self._decide(
            trust_score, risk_score, evidence_score,
            conflict_detected, security_flags, len(agent_responses)
        )

        self._update_history(best["agent"], decision)

        return DecisionResult(
            decision=decision,
            trust_score=trust_score,
            risk_score=risk_score,
            evidence_score=evidence_score,
            conflict_detected=conflict_detected,
            security_flags=security_flags,
            explanation=explanation,
            per_agent=per_agent_scores,
        )

    def _decide(self, trust_score, risk_score, evidence_score,
                conflict_detected, security_flags, n_agents):
        if security_flags:
            return "ESCALATE_TO_HUMAN", (
                f"Security-sensitive terms detected ({', '.join(security_flags)}). "
                f"Routed to a human agent rather than letting an AI agent act on this."
            )

        if risk_score >= 60:
            return "ESCALATE_TO_HUMAN", (
                f"Risk score {risk_score:.0f}/100 is above the safety threshold "
                f"(high-value or urgency-flagged request). Escalating for human review."
            )

        if conflict_detected and n_agents > 1:
            return "INVOKE_ADDITIONAL_AGENT", (
                f"Multiple agents ({n_agents}) responded to this query with overlapping "
                f"intents. Trust score {trust_score:.0f}/100 is not yet high enough to pick "
                f"one automatically -- invoking a tie-breaking check before responding."
            )

        if trust_score >= 75 and risk_score < 40 and evidence_score >= 50:
            return "ACCEPT", (
                f"Trust score {trust_score:.0f}/100 and evidence score {evidence_score:.0f}/100 "
                f"are both high, risk score {risk_score:.0f}/100 is low. Response accepted "
                f"and returned to the customer automatically."
            )

        if trust_score >= 50:
            if evidence_score < 50:
                reason = (f"evidence ({evidence_score:.0f}/100) is incomplete "
                          f"(e.g. missing order ID / amount)")
            else:
                reason = f"risk ({risk_score:.0f}/100) is elevated for this request"
            return "REQUEST_VERIFICATION", (
                f"Trust score {trust_score:.0f}/100 is moderate and {reason}. "
                f"Asking the customer to confirm one more detail before acting."
            )

        return "ESCALATE_TO_HUMAN", (
            f"Trust score {trust_score:.0f}/100 is too low to act on automatically "
            f"and evidence is weak. Escalating to a human support agent."
        )

    def _update_history(self, agent_name: str, decision: str):
        current = self.history.get(agent_name, 0.75)
        if decision == "ACCEPT":
            new = min(current + 0.01, 0.99)
        elif decision == "ESCALATE_TO_HUMAN":
            new = max(current - 0.01, 0.4)
        else:
            new = current
        self.history[agent_name] = round(new, 4)
        _save_history(self.history)
