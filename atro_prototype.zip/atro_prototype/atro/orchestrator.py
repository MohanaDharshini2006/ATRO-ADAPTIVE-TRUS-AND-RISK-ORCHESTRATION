"""
ATRO Orchestrator.

Static orchestration (in the problem statement's sense) would just route a
query to one hardcoded agent and return its answer. This orchestrator instead:
  1. classifies intent (can match >1 agent -> simulates conflicting agents)
  2. calls every matched agent
  3. hands all responses to the Decision Intelligence Layer
  4. returns the layer's decision, not the raw agent output
"""

from .agents import AGENT_REGISTRY
from .decision_layer import DecisionIntelligenceLayer

INTENT_KEYWORDS = {
    "billing": ["bill", "invoice", "charge", "charged", "payment", "overcharg", "subscription fee"],
    "refund": ["refund", "return my", "money back", "reimburse", "cancel my order"],
    "order": ["track", "shipment", "delivery", "shipped", "where is my order", "package"],
    "technical": ["not working", "error", "bug", "login", "password", "crash", "can't access", "otp"],
}


def classify_intents(query: str) -> list:
    ql = query.lower()
    matched = []
    for intent, keywords in INTENT_KEYWORDS.items():
        if any(kw in ql for kw in keywords):
            matched.append(intent)
    if not matched:
        matched = ["technical"]  # fallback bucket for unrecognized queries
    return matched


class ATROOrchestrator:
    def __init__(self):
        self.decision_layer = DecisionIntelligenceLayer()

    def handle(self, query: str) -> dict:
        intents = classify_intents(query)
        agent_responses = [AGENT_REGISTRY[intent].respond(query) for intent in intents]

        result = self.decision_layer.evaluate(query, agent_responses)

        return {
            "query": query,
            "matched_intents": intents,
            "agent_responses": [
                {"agent": ar.agent_name, "response": ar.response_text,
                 "self_confidence": ar.self_confidence, "evidence": ar.evidence}
                for ar in agent_responses
            ],
            "decision": result.decision,
            "trust_score": result.trust_score,
            "risk_score": result.risk_score,
            "evidence_score": result.evidence_score,
            "conflict_detected": result.conflict_detected,
            "security_flags": result.security_flags,
            "explanation": result.explanation,
            "per_agent_scores": result.per_agent,
        }
