"""
Domain agents for ATRO prototype.

Each agent is intentionally simple (rule/template based, no external LLM
call) so the whole pipeline runs offline and deterministically for a demo.
In a production version, `respond()` would call a real fine-tuned or
prompted LLM per domain; here it simulates that agent's output plus a
self-reported confidence, which is exactly the kind of signal the
Decision Intelligence Layer is designed to not blindly trust.
"""

import random
import re
from dataclasses import dataclass, field


@dataclass
class AgentResponse:
    agent_name: str
    response_text: str
    self_confidence: float          # 0-1, what the agent claims about itself
    evidence: dict = field(default_factory=dict)  # extracted supporting facts


def _extract_order_id(text: str):
    m = re.search(r"\b(?:ord|order)[\s#-]*([a-z0-9]{4,10})\b", text, re.I)
    return m.group(1).upper() if m else None


def _extract_amount(text: str):
    m = re.search(r"(?:rs\.?|inr|\$|usd)\s?(\d+(?:\.\d{1,2})?)", text, re.I)
    return float(m.group(1)) if m else None


class BaseAgent:
    name = "base"

    def respond(self, query: str) -> AgentResponse:
        raise NotImplementedError


class BillingAgent(BaseAgent):
    name = "billing_agent"

    def respond(self, query: str) -> AgentResponse:
        amount = _extract_amount(query)
        evidence = {}
        if amount:
            evidence["amount_found"] = amount
        if "overcharg" in query.lower() or "wrong amount" in query.lower():
            text = (f"I checked your latest invoice. If an incorrect amount of "
                     f"{amount if amount else 'the disputed value'} was charged, "
                     f"I can raise a billing correction request.")
            conf = 0.72 if amount else 0.55
        elif "subscription" in query.lower():
            text = "Your subscription is active. I can show your next billing date or help you change your plan."
            conf = 0.8
        else:
            text = "I can pull up your billing history and explain any charge on your account."
            conf = 0.65
        evidence["intent_signal"] = "billing"
        return AgentResponse(self.name, text, conf, evidence)


class RefundAgent(BaseAgent):
    name = "refund_agent"

    def respond(self, query: str) -> AgentResponse:
        order_id = _extract_order_id(query)
        amount = _extract_amount(query)
        evidence = {}
        if order_id:
            evidence["order_id"] = order_id
        if amount:
            evidence["amount_found"] = amount

        if order_id:
            text = (f"Order {order_id} is eligible for refund review. "
                     f"I can initiate a refund of "
                     f"{amount if amount else 'the paid amount'} pending verification.")
            conf = 0.78
        else:
            text = ("I can help with a refund, but I need the order ID to verify "
                     "eligibility before initiating anything.")
            conf = 0.45
        evidence["intent_signal"] = "refund"
        return AgentResponse(self.name, text, conf, evidence)


class OrderAgent(BaseAgent):
    name = "order_agent"

    def respond(self, query: str) -> AgentResponse:
        order_id = _extract_order_id(query)
        evidence = {}
        if order_id:
            evidence["order_id"] = order_id
            status = random.choice(["Shipped", "Out for delivery", "In transit", "Delayed"])
            evidence["status"] = status
            text = f"Order {order_id} status: {status}."
            conf = 0.85
        else:
            text = "I can track your order once you share the order ID."
            conf = 0.4
        evidence["intent_signal"] = "order"
        return AgentResponse(self.name, text, conf, evidence)


class TechSupportAgent(BaseAgent):
    name = "tech_support_agent"

    def respond(self, query: str) -> AgentResponse:
        evidence = {"intent_signal": "technical"}
        ql = query.lower()
        if "password" in ql or "otp" in ql or "login" in ql:
            text = ("For login/password issues I can trigger a secure reset link to "
                     "your registered email. I will not ask you to share your password or OTP here.")
            conf = 0.7
            evidence["sensitive_topic"] = True
        elif "not working" in ql or "error" in ql or "bug" in ql or "crash" in ql:
            text = "I can see this looks like a app-level error. I can log a technical ticket and share known workarounds."
            conf = 0.6
        else:
            text = "Could you describe the technical issue in more detail so I can diagnose it?"
            conf = 0.4
        return AgentResponse(self.name, text, conf, evidence)


AGENT_REGISTRY = {
    "billing": BillingAgent(),
    "refund": RefundAgent(),
    "order": OrderAgent(),
    "technical": TechSupportAgent(),
}
