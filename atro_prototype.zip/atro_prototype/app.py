import streamlit as st
from atro.orchestrator import ATROOrchestrator

st.set_page_config(page_title="ATRO - Adaptive Trust & Risk Orchestrator", layout="centered")

if "orchestrator" not in st.session_state:
    st.session_state.orchestrator = ATROOrchestrator()

st.title("ATRO: Adaptive Trust & Risk Orchestrator")
st.caption("Decision Intelligence Layer demo prototype — Billing, Refund, Order & Tech Support agents")

DECISION_COLOR = {
    "ACCEPT": "green",
    "REQUEST_VERIFICATION": "orange",
    "INVOKE_ADDITIONAL_AGENT": "orange",
    "ESCALATE_TO_HUMAN": "red",
}

examples = {
    "-- pick a sample query --": "",
    "Simple order tracking": "Where is my order ORD1234, it was supposed to arrive yesterday?",
    "Refund with missing evidence": "I want a refund for my last purchase, please return my money.",
    "Overlapping billing + refund (conflict)": "I was overcharged Rs 1500 on my subscription, refund my money back now.",
    "Security-sensitive request": "My login is not working, can you just send me the OTP for verification?",
    "High-value urgent request": "Refund me $8000 immediately, this is urgent, order ORD9981.",
}

choice = st.selectbox("Try a sample query", list(examples.keys()))
query = st.text_area("Customer query", value=examples[choice], height=90,
                      placeholder="Type a customer support query...")

if st.button("Run through ATRO", type="primary") and query.strip():
    result = st.session_state.orchestrator.handle(query)

    st.subheader("Agents invoked")
    for ar in result["agent_responses"]:
        with st.container(border=True):
            st.markdown(f"**{ar['agent']}**  (self-confidence: {ar['self_confidence']:.2f})")
            st.write(ar["response"])
            if ar["evidence"]:
                st.caption(f"Evidence extracted: {ar['evidence']}")

    st.subheader("Decision Intelligence Layer")
    c1, c2, c3 = st.columns(3)
    c1.metric("Trust score", f"{result['trust_score']:.0f}/100")
    c2.metric("Risk score", f"{result['risk_score']:.0f}/100")
    c3.metric("Evidence score", f"{result['evidence_score']:.0f}/100")

    if result["security_flags"]:
        st.warning(f"Security flags detected: {', '.join(result['security_flags'])}")
    if result["conflict_detected"] and len(result["agent_responses"]) > 1:
        st.info(f"{len(result['agent_responses'])} agents matched this query — conflict resolution engaged.")

    color = DECISION_COLOR.get(result["decision"], "gray")
    st.markdown(f"### Final decision: :{color}[{result['decision'].replace('_', ' ')}]")
    st.write(result["explanation"])

    with st.expander("Raw per-agent trust breakdown (for judges / debugging)"):
        st.json(result["per_agent_scores"])

st.divider()
st.caption(
    "This is a rule-based prototype demonstrating the Decision Intelligence Layer's logic "
    "(trust scoring, risk scoring, evidence checks, conflict detection, historical performance). "
    "In production, agent responses would come from fine-tuned/prompted LLMs and the scoring "
    "weights would be learned from labeled outcome data instead of hand-set."
)
