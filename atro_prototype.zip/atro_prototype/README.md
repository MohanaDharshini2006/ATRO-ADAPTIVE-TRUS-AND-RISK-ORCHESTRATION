# ATRO — Adaptive Trust & Risk Orchestrator (10% prototype)

A working, offline, rule-based prototype of the **Decision Intelligence Layer**
described in the problem statement. It shows the *mechanism* the full system
would use — not a production fraud model, but real, runnable scoring logic
you can demo live.

## What's actually implemented (be upfront about this in review)

- 4 domain agents (billing, refund, order, tech support) — simple, deterministic,
  template-based responders that also extract "evidence" (order IDs, amounts)
  and report a self-confidence score.
- An intent router that can match a query to **more than one agent at once**,
  simulating the "conflicting agent responses" problem from the brief.
- A real **Decision Intelligence Layer** that computes, from actual signals:
  - **Trust score** = blend of agent self-confidence + evidence quality + historical agent accuracy
  - **Risk score** = security keyword detection + high-value/urgency heuristics
  - **Evidence score** = whether the response is actually grounded (order ID found? amount found?)
  - **Conflict detection** = did more than one agent respond?
  - A **historical performance tracker** that nudges each agent's trust up/down
    after every decision (persisted to `atro/agent_history.json`) — a toy version
    of "learning" agent reliability over time.
- Four possible outcomes, each with a plain-English explanation: **ACCEPT**,
  **REQUEST_VERIFICATION**, **INVOKE_ADDITIONAL_AGENT**, **ESCALATE_TO_HUMAN**.

## What's simulated / simplified (say this too — it shows you understand the gap)

- Agents are rule-based, not real LLM calls (swap in an API call per agent later).
- No real fraud/ML model — risk scoring is heuristic (keyword + amount + urgency).
  A real version would use anomaly detection, device/IP signals, and account history.
- No auth, no real database, no multi-turn memory.
- Scoring weights are hand-set, not learned from labeled outcome data.

This scoping is deliberate: it proves the **architecture and decision logic**
end-to-end, which is the actual novelty being pitched, without pretending to
have solved fraud detection or hallucination detection in one night.

## How to run

```bash
cd atro_prototype
pip install -r requirements.txt

# Option A: interactive UI (recommended for the review)
streamlit run app.py

# Option B: no UI, just terminal output
python demo_cli.py
```

## Suggested demo script (~3 minutes)

1. Run **"Simple order tracking"** → high trust, low risk → **ACCEPT**.
   "This is the happy path — most requests should end here."
2. Run **"Refund with missing evidence"** → low trust (no order ID) → **ESCALATE**.
   "The agent is honest that it's under-confident, but low evidence + low trust
   means we don't act on it blindly."
3. Run **"Overlapping billing + refund (conflict)"** → two agents fire →
   **INVOKE_ADDITIONAL_AGENT**. "This is the multi-agent conflict scenario from
   the brief — static orchestration would just pick one agent arbitrarily."
4. Run **"Security-sensitive request"** (asks for OTP) → **ESCALATE**, security
   flag shown. "This is the fraud/security angle — regardless of trust score,
   certain requests always go to a human."
5. Run **"High-value urgent request"** → moderate trust but elevated risk →
   **REQUEST_VERIFICATION**. "Urgency + large amount is a classic social
   engineering pattern, so we ask for one more confirmation instead of
   auto-approving."

## Where this goes next (for the "future work" slide)

- Replace each `AgentResponse` with a real LLM call (Anthropic API), keeping
  the same `AgentResponse` interface so the Decision Intelligence Layer doesn't change.
- Replace hand-set weights with a small classifier trained on labeled
  accept/escalate outcomes.
- Add a real risk model: device fingerprinting, IP reputation, transaction
  velocity, account age.
- Add a human-in-the-loop review queue for ESCALATE_TO_HUMAN cases with a
  feedback signal that updates `agent_history.json`.

## File map

```
atro_prototype/
  atro/
    agents.py          domain agents (billing, refund, order, tech support)
    decision_layer.py  trust/risk/evidence scoring + final decision logic
    orchestrator.py     intent routing + ties agents to the decision layer
    agent_history.json  auto-created; simulated learned agent reliability
  app.py                Streamlit demo UI
  demo_cli.py           terminal-only fallback demo
  requirements.txt
```
